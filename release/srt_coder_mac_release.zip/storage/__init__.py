"""Storage repositories."""

